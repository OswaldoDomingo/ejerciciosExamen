<?php
session_start();

echo $_SESSION['nombreTarea'] = $nombreTarea;
echo "<br>";
echo $_SESSION['descripcion'] = $descripcion;
echo "<br>";
echo $_SESSION['fechaVencimiento'] = $fechaVencimiento;
echo "<br>";
echo $_SESSION['imagen'] = $imagen;
echo "<br>";
echo $_SESSION['tipoTarea'] = $tipoTarea;



?>
<form method="post" action="procesar_formulario.php" enctype="multipart/form-data">
        <p>Nombre de la Tarea:</p>
        <input type="text" name="nombreTarea" >
        <br>

        <p>Descripción:</p>
        <textarea name="descripcion" rows="4" cols="50" ></textarea>
        <br>

        <p>Fecha de Vencimiento:</p>
        <input type="date" name="fechaVencimiento" >
        <br>


        <p>Tipo de tarea:</p>
        <label for="">Familiar</label>
        <input type="checkbox" name="tipoTarea[]" value=“familiar”>
        <label for="">Trabajo</label>
        <input type="checkbox" name="tipoTarea[]" value=“trabajo”>
        <label for="">Ocio</label>
        <input type="checkbox" name="tipoTarea[]" value=“ocio”>

        <br>

        <p>Adjuntar Imagen:</p>
        <input type="file" name="imagen">
        <br>

        <input type="submit" value="Crear Tarea">
    </form>

<?php
session_start();

require 'bgeneral.php';

$tipoImagen = array('jpeg', 'jpg', 'png', 'bmp', 'pdf');
$valoresTipoTarea = array('familiar', 'trabajo', 'ocio');
$directorio = "imagenes/";
$max_file_size = 50000;

$nombreTarea = recoge('nombreTarea');
$descripcion = recoge('descripcion');
$fechaVencimiento = recoge('fechaVencimiento');
$imagen = recoge('imagen');
$errores = array();
$tipoTarea = recogeArray('tipoTarea');


cTexto($nombreTarea, 'nombreTarea', $errores, 60, 1);
cTexto($descripcion, 'descripcion', $errores, 200, 0);
ValidaFechadma($fechaVencimiento, 'fechaVencimiento', $errores);
//Falta ver si la fecha es la actual o posterior 🤦‍♂️
cFile($imagen, $errores, $tipoImagen, $directorio, $max_file_size, false);
cCheck($tipoTarea, 'tipoTarea', $errores, $valoresTipoTarea, false);


if(empty($errores)){
    $_SESSION['nombreTarea'] = $nombreTarea;
    $_SESSION['descripcion'] = $descripcion;
    $_SESSION['fechaVencimiento'] = $fechaVencimiento;
    $_SESSION['imagen'] = $imagen;
    $_SESSION['tipoTarea'] = $tipoTarea;

    header("Location:confirmacionTarea.php");
}
?>
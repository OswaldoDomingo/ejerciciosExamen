<?php

class Config {
    public static $mvc_bd_hostname = "localhost";
    public static $mvc_bd_nombre = "examenExtraordinaria";
    public static $mvc_bd_usuario = "root";
    public static $mvc_bd_clave = "";
    public static $mvc_vis_css = "estilo.css";
 
}
?>
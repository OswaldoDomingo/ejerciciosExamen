<?php 
require_once 'Model.php';
class Pelicula extends Model {

    //Listar todas las películas
   public function listar(){
    $consulta = "SELECT * FROM pelicula";
    $resultado = $this->conexion->prepare($consulta);
    $resultado->execute();
    return $resultado->fetchAll(PDO::FETCH_ASSOC);
   }

   public function insertarArticulos($fechaCreacion, $resumen, $titulo,  $duracion){

    $consulta = "INSERT INTO pelicula VALUES (:fecha, :resumen, :titulo, :duracion)";
    $resultado = $this->conexion->prepare($consulta);
    $resultado->bindParam('fecha', $fechaCreacion);
    $resultado->bindParam('resumen', $resumen);
    $resultado->bindParam('titulo', $titulo);
    $resultado->bindParam('duracion', $duracion);

    $resultado->execute();
   }

   //LOGIN
   public function login($user){
    $consulta = "SELECT * FROM users WHERE user = :usuario";
    $resultado = $this->conexion->prepare($consulta);
    $resultado->bindParam(':usuario', $user);
    $resultado->execute();
    return $resultado->fetchALL(PDO::FETCH_ASSOC);    
}
    
    
    
}


?>
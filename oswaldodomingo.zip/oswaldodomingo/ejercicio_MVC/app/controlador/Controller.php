<?php

class Controller
{
    //Cargar menú según el nivel del usuario
    public function cargaMenu()
    {
        if ($_SESSION['nivel_usuario'] == 0) {
            return 'menu0.php';
        } else if ($_SESSION['nivel_usuario'] == 1) {
            return 'menu1.php';
        } else if ($_SESSION['nivel_usuario'] == 2) {
            return 'menu2.php';
        }
    }

    public function inicio()
    {
        $params['mensaje'] = 'Bienvenido al examen de Servidor de la Convocatoria Extraordinaria';



        try {

            $this->cargaMenu();
        } catch (PDOException $e) {
            // En este caso guardamos los errores en un archivo de errores log
            error_log($e->getMessage() . "##Código: " . $e->getCode() . "  " . microtime() . PHP_EOL, 3, "../log.txt");
            // guardamos en ·errores el error que queremos mostrar a los usuarios

        }


        require __DIR__ . '/../../web/templates/inicio.php';
    }



    public function error()
    {

        require __DIR__ . '/../../web/templates/error.php';
    }



    //SALIR
    public function salir()
    {
        session_destroy();
        header('Location:index.php?ctl=inicio');
    }


    //INSERTAR PELÍCULAS
    public function insertarArticulos()
    {
        $fechaCreacion = '';
        $resumen = '';
        $titulo = '';
        $duracion = '';
        $errores = array();


        try {
            $fechaCreacion = recoge('fechaCreacion');
            $resumen = recoge('resumen');
            $titulo = recoge('titulo');
            $duracion = recoge('duracion');

            cTexto($resumen, 'resumen', $errores);
            cTexto($titulo, 'titulo', $errores);
            cNum($duracion, 'duracion', $errores);

            if (empty($errores)) {
                $m = new Pelicula();
                $m->insertarArticulos($fechaCreacion, $resumen, $titulo, $duracion);
            }
        } catch (PDOException $e) {
            // En este caso guardamos los errores en un archivo de errores log
            error_log($e->getMessage() . "##Código: " . $e->getCode() . "  " . microtime() . PHP_EOL, 3, "../log.txt");
            // guardamos en ·errores el error que queremos mostrar a los usuarios

        }
        require __DIR__ . "/../../web/templates/insertarPelicula.php";

    }

    public function login(){
        $usuario = '';
        $pass = '';
        $errores = array();

        try {

        $usuario = recoge('usuario');
        $pass = recoge('pass');

        cUser($usuario, 'usuario', $errores);

        if(empty($errores)){
            $m = new Pelicula();
            $campo = $m->login($usuario);

            if($usuario == $campo['user'] && $pass == $campo['pass']){

                header('Location: index.php?ctl=listarPeliculas.php');
            } else {
                header('Location: index.php?ctl=error.php');

            }
        }
    }catch (PDOException $e) {
            // En este caso guardamos los errores en un archivo de errores log
            error_log($e->getMessage() . "##Código: " . $e->getCode() . "  " . microtime() . PHP_EOL, 3, "../log.txt");
            // guardamos en ·errores el error que queremos mostrar a los usuarios

        }

        require __DIR__ . "/../../web/templates/login.php";

    }

    public function listar(){
        try{
            $m = new Pelicula();
            
            $listadoPeliculas = $m->listar(); 

        }catch (PDOException $e) {
            // En este caso guardamos los errores en un archivo de errores log
            error_log($e->getMessage() . "##Código: " . $e->getCode() . "  " . microtime() . PHP_EOL, 3, "../log.txt");
            // guardamos en ·errores el error que queremos mostrar a los usuarios

        }
        require __DIR__ . "/../../web/templates/listarPeliculas.php";
    }

}

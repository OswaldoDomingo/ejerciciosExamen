<div id="menu">
<hr/>

<a href="index.php?ctl=login">Login</a> |
<a href="index.php?ctl=listar">Listar peliculas</a> |

<hr/>
</div>
<div id="menu">
<hr/>
<a href="index.php?ctl=inicio">Inicio</a> 
<a href="index.php?ctl=listar">Listar peliculas</a> 
<a href="index.php?ctl=insertar">Insertar peliculas</a> 
<a href="index.php?ctl=salir">Cerrar Sesión</a> 

<hr/>
</div>
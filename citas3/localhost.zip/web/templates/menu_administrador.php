<!-- menu_administrador.php -->
<h3>Bienvenido <?php echo $_SESSION['nombreUsuario'] ?></h3>
<a href="index.php?ctl=home">Inicio</a>
<a href="index.php?ctl=citasPublicas">Listar citas</a>
<a href="index.php?ctl=usuarios">Listar usuarios</a>
<a href="index.php?ctl=salir">Salir</a>





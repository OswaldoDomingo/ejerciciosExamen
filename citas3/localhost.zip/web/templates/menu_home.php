<!-- menu_home.php -->
<div class="nav">
    <a href="index.php?ctl=login">Login</a>
    <a href="index.php?ctl=registro">Registrarse</a>
    <a href="index.php?ctl=inicio">Invitado</a>
</div>
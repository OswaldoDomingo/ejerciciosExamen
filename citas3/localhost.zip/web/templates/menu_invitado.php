<!-- menu_invitado.php  -->

 <h3>Bienvenido invitado</h3>
 <div class="nav">
 <a href="index.php?ctl=home">Inicio</a>
<a href="index.php?ctl=citasPublicas">Listar citas públicas</a>
 </div>